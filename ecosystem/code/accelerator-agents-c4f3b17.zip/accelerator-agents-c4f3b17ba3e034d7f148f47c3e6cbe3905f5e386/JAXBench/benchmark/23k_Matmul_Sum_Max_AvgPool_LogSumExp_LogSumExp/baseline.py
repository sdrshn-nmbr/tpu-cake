"""18_Matmul_Sum_Max_AvgPool_LogSumExp_LogSumExp — JAXBench fused operator workload."""
import jax
import jax.numpy as jnp

CONFIG = {
    'name': '18_Matmul_Sum_Max_AvgPool_LogSumExp_LogSumExp',
    'batch_size': 4096,
    'in_features': 8192,
    'out_features': 8192,
}


def create_inputs(dtype=jnp.float32):
    """Create all inputs including weights."""
    key = jax.random.key(0)
    rand_key = jax.random.key(0xBADC0DE)
    ka, kb = jax.random.split(rand_key, 2)
    x = jax.random.uniform(key, (4096, 8192), dtype=dtype)
    weight = jax.random.normal(ka, (8192, 8192), dtype=dtype) * 0.02
    bias = jax.random.normal(kb, 8192, dtype=dtype) * 0.02
    return x, weight, bias


def workload(x, weight, bias):
    """Matmul + Sum + Max + AvgPool + LogSumExp + LogSumExp."""
    x = jnp.matmul(x, weight.T) + bias
    x = jnp.sum(x, axis=1, keepdims=True)
    x = jnp.max(x, axis=1, keepdims=True)
    x = jnp.mean(x, axis=1, keepdims=True)
    x = jax.scipy.special.logsumexp(x, axis=1, keepdims=True)
    x = jax.scipy.special.logsumexp(x, axis=1, keepdims=True)
    return x

def benchmark(num_warmup=5, num_iters=100):
    """Benchmark and return results dict."""
    import time
    inputs = create_inputs()
    fn = jax.jit(workload)
    for _ in range(num_warmup):
        out = fn(*inputs)
        if hasattr(out, 'block_until_ready'):
            out.block_until_ready()
    times = []
    for _ in range(num_iters):
        t0 = time.perf_counter()
        out = fn(*inputs)
        if hasattr(out, 'block_until_ready'):
            out.block_until_ready()
        times.append(time.perf_counter() - t0)
    import numpy as np
    times_ms = np.array(times) * 1000
    avg = float(np.mean(times_ms))
    return {
        'name': CONFIG['name'],
        'config': {k: v for k, v in CONFIG.items() if k != 'name'},
        'time_ms': round(avg, 4),
        'std_ms': round(float(np.std(times_ms)), 4),
        'output_shape': list(out.shape) if hasattr(out, 'shape') else [],
        'status': 'success',
    }


if __name__ == '__main__':
    import json
    print(json.dumps(benchmark()))
