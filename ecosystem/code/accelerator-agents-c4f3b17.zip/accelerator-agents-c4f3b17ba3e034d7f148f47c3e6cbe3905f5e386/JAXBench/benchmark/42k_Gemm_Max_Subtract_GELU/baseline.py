"""80_Gemm_Max_Subtract_GELU — JAXBench fused operator workload."""
import jax
import jax.numpy as jnp

CONFIG = {
    'name': '80_Gemm_Max_Subtract_GELU',
    'batch_size': 4096,
    'in_features': 8192,
    'out_features': 8192,
    'max_dim': 1,
}


def create_inputs(dtype=jnp.float32):
    """Create all inputs including weights."""
    key = jax.random.key(0)
    k_x, k_w, k_b = jax.random.split(key, 3)
    x = jax.random.uniform(k_x, (4096, 8192), dtype=dtype)
    weight = jax.random.normal(k_w, (8192, 8192), dtype=dtype) * 0.02
    bias = jax.random.normal(k_b, 8192, dtype=dtype) * 0.02
    return x, weight, bias


def workload(x, weight, bias):
    """Gemm + Max + Subtract(max) + GELU."""
    x = jnp.matmul(x, weight) + bias
    x_max = jnp.max(x, axis=1, keepdims=True)
    x = x - x_max
    x = jax.nn.gelu(x)
    return x

def benchmark(num_warmup=5, num_iters=100):
    """Benchmark and return results dict."""
    import time
    inputs = create_inputs()
    fn = jax.jit(workload)
    for _ in range(num_warmup):
        out = fn(*inputs)
        if hasattr(out, 'block_until_ready'):
            out.block_until_ready()
    times = []
    for _ in range(num_iters):
        t0 = time.perf_counter()
        out = fn(*inputs)
        if hasattr(out, 'block_until_ready'):
            out.block_until_ready()
        times.append(time.perf_counter() - t0)
    import numpy as np
    times_ms = np.array(times) * 1000
    avg = float(np.mean(times_ms))
    return {
        'name': CONFIG['name'],
        'config': {k: v for k, v in CONFIG.items() if k != 'name'},
        'time_ms': round(avg, 4),
        'std_ms': round(float(np.std(times_ms)), 4),
        'output_shape': list(out.shape) if hasattr(out, 'shape') else [],
        'status': 'success',
    }


if __name__ == '__main__':
    import json
    print(json.dumps(benchmark()))
