"""84_Gemm_BatchNorm_Scaling_Softmax — JAXBench fused operator workload."""
import jax
import jax.numpy as jnp

CONFIG = {
    'name': '84_Gemm_BatchNorm_Scaling_Softmax',
    'batch_size': 4096,
    'in_features': 8192,
    'out_features': 8192,
    'bn_eps': 1e-05,
    'bn_momentum': 0.1,
}


def create_inputs(dtype=jnp.float32):
    """Create all inputs including weights."""
    key = jax.random.key(0)
    rand_key = jax.random.key(42)
    ka, kb, kc = jax.random.split(rand_key, 3)
    batch_size, in_features, out_features = 4096, 8192, 8192
    x = jax.random.uniform(key, (batch_size, in_features), dtype=dtype)
    weight = jax.random.normal(ka, (in_features, out_features), dtype=dtype) * 0.02
    bias = jax.random.normal(kb, out_features, dtype=dtype) * 0.02
    bn_scale = jnp.ones(out_features, dtype=dtype)
    bn_bias = jax.random.normal(kc, out_features, dtype=dtype) * 0.02
    bn_mean = jnp.zeros(out_features, dtype=dtype)
    bn_var = jnp.ones(out_features, dtype=dtype)
    scale = jnp.ones((1,), dtype=dtype)
    return x, weight, bias, bn_scale, bn_bias, bn_mean, bn_var, scale


def workload(x, weight, bias, bn_scale, bn_bias, bn_mean, bn_var, scale):
    """Gemm + BatchNorm + Scaling + Softmax."""
    bn_eps = 1e-5
    # Linear
    x = jnp.matmul(x, weight) + bias
    # BatchNorm (eval mode with running stats)
    x_normalized = (x - bn_mean) / jnp.sqrt(bn_var + bn_eps)
    x = bn_scale * x_normalized + bn_bias
    # Scale
    x = scale * x
    # Softmax
    x = jax.nn.softmax(x, axis=1)
    return x

def benchmark(num_warmup=5, num_iters=100):
    """Benchmark and return results dict."""
    import time
    inputs = create_inputs()
    fn = jax.jit(workload)
    for _ in range(num_warmup):
        out = fn(*inputs)
        if hasattr(out, 'block_until_ready'):
            out.block_until_ready()
    times = []
    for _ in range(num_iters):
        t0 = time.perf_counter()
        out = fn(*inputs)
        if hasattr(out, 'block_until_ready'):
            out.block_until_ready()
        times.append(time.perf_counter() - t0)
    import numpy as np
    times_ms = np.array(times) * 1000
    avg = float(np.mean(times_ms))
    return {
        'name': CONFIG['name'],
        'config': {k: v for k, v in CONFIG.items() if k != 'name'},
        'time_ms': round(avg, 4),
        'std_ms': round(float(np.std(times_ms)), 4),
        'output_shape': list(out.shape) if hasattr(out, 'shape') else [],
        'status': 'success',
    }


if __name__ == '__main__':
    import json
    print(json.dumps(benchmark()))
