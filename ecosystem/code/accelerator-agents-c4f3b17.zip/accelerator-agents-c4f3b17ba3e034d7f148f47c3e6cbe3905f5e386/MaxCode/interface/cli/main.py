"""Standard CLI implementation."""
