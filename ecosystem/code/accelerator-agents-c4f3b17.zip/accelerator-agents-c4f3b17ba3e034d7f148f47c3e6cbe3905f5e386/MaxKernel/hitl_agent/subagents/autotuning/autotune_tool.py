"""Standalone tool for auto-tuning Pallas kernels using grid search on remote servers."""

import json
import logging
import subprocess
from typing import Any

import requests

from hitl_agent.constants import AUTOTUNE_TIMEOUT, EVAL_SERVER_PORT


def autotune_kernel(
  kernel_name: str,
  code_template: str,
  search_space: dict[str, list[Any]],
  backend: str = None,
  server_addr: str = "http://localhost",
) -> dict:
  """Runs a grid search to auto-tune a Pallas kernel on a remote server.

  Args:
      kernel_name: Name of the kernel.
      code_template: Python code containing placeholders for parameters to be
        tuned. It should produce a line like "RESULT_TIME: <float>" in its
        output to indicate performance.
      search_space: A dictionary mapping placeholder names to lists of feasible
        values.
      backend: 'tpu' or 'cpu'.
      server_addr: Address of the server (default: http://localhost).

  Returns:
      A dictionary containing the status, optimal parameters, and a summary of
      results.
  """
  logging.info(
    f"Starting remote autotuning for kernel: {kernel_name} on {backend}"
  )

  url = f"{server_addr}:{EVAL_SERVER_PORT}/evaluate"

  try:
    response = requests.post(
      url,
      json={
        "eval_type": "autotune",
        "code_template": code_template,
        "search_space": search_space,
        "timeout": 300,
        "backend_type": backend,
      },
      timeout=AUTOTUNE_TIMEOUT,  # timeout for the whole autotune request
    )

    if response.status_code == 200:
      result = response.json()
      if result["exit_code"] == 0:
        try:
          output_data = json.loads(result["output"])
          logging.info(
            f"Autotuning completed. Best config: {output_data['best_cfg']}"
            f" with time {output_data['best_time']} ms"
          )
          return {
            "status": "success",
            "message": "Autotuning completed",
            "best_config": output_data["best_cfg"],
            "best_time_ms": output_data["best_time"],
            "best_output": output_data["best_output"],
            "all_results": output_data.get("all_results", []),
          }
        except json.JSONDecodeError:
          logging.warning("Failed to decode JSON from server output.")
          return {
            "status": "success",
            "message": "Autotuning completed (raw output)",
            "raw_output": result["output"],
          }
      else:
        try:
          output_data = json.loads(result["output"])
          return {
            "status": "failed",
            "message": result["error"] or "Autotune failed on server",
            "all_results": output_data.get("all_results", []),
          }
        except Exception:
          return {
            "status": "failed",
            "message": result["error"] or "Autotune failed on server",
            "server_output": result["output"],
          }
    else:
      return {
        "status": "error",
        "message": (
          f"Server returned status code {response.status_code}: {response.text}"
        ),
      }

  except requests.exceptions.ConnectionError:
    return {
      "status": "error",
      "message": (
        f"Could not connect to server at {url}. Make sure it is running."
      ),
    }
  except requests.exceptions.Timeout:
    logging.warning(
      "Autotune timed out on client side. Cleaning up dangling subprocesses on server..."
    )
    try:
      subprocess.run(["pkill", "-9", "-f", "tpu_server.py"], check=False)
      subprocess.run(["pkill", "-9", "-f", "cpu_server.py"], check=False)
      subprocess.run(["pkill", "-f", "/tmp/hitl_eval_.*\\.py"], check=False)
      logging.info("Killed dangling evaluations and tpu_server.py")
    except Exception as cleanup_error:
      logging.error(f"Failed to run cleanup commands: {cleanup_error}")

    return {
      "status": "error",
      "message": f"Autotune request timed out after {AUTOTUNE_TIMEOUT} seconds. Dangling processes were killed.",
    }
  except Exception as e:
    return {"status": "error", "message": str(e)}
