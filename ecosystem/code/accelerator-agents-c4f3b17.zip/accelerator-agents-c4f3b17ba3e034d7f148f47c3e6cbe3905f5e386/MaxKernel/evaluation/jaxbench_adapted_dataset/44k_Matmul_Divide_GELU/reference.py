# Imports
import jax
import jax.numpy as jnp

# Initialization
def get_inputs():
    batch_size = 4096
    input_size = 8192
    output_size = 8192
    divisor = 10.0
    dtype = jnp.float32

    key = jax.random.key(0)
    rand_key = jax.random.key(0xBADC0DE)
    ka, kb = jax.random.split(rand_key, 2)
    x = jax.random.uniform(key, (batch_size, input_size), dtype=dtype)
    weight = jax.random.normal(ka, (input_size, output_size), dtype=dtype) * 0.02
    bias = jax.random.normal(kb, output_size, dtype=dtype) * 0.02

    dynamic_args = [x, weight, bias]
    static_args = [divisor]
    return dynamic_args, static_args

# Computation
def computation(x, weight, bias, divisor):
    x = x @ weight + bias
    x = x / divisor
    x = jax.nn.gelu(x)
    return x