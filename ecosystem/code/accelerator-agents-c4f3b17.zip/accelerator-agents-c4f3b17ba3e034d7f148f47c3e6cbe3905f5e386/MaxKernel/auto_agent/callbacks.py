"""Callback utilities for HITL kernel generation agents."""

import json
import logging
import os
from typing import Any, Dict, Optional

from google.adk.agents.callback_context import CallbackContext
from google.adk.models import LlmRequest, LlmResponse
from google.adk.tools import BaseTool, ToolContext
from google.genai import types

from auto_agent.config import TPU_VERSION, WORKDIR
from auto_agent.knowledge_base import pallas_docs, pallas_profiling_docs


def create_path_saver(state_key: str):
  """
  Factory function that creates a callback to save file paths to a specific state key.

  Args:
      state_key: The key in tool_context.state where the file path will be saved.

  Returns:
      A callback function compatible with after_tool_callback signature.
  """

  def save_path(
    tool: BaseTool,
    args: Dict[str, Any],
    tool_context: ToolContext,
    tool_response: Optional[Dict],
  ) -> Optional[Dict]:
    # MCP filesystem tools may have different naming patterns
    # Check for both snake_case and potential prefixed versions
    if "read" in tool.name.lower() or "write" in tool.name.lower():
      file_path = args.get("path", None)
      if file_path:
        basename = os.path.basename(file_path).lower()
        should_save = False

        if (
          state_key == "test_file_path"
          and file_path.endswith(".py")
          and "test" in basename
        ):
          should_save = True
        elif (
          state_key == "profiling_script_path"
          and file_path.endswith(".py")
          and "profile" in basename
        ):
          should_save = True
        elif (
          state_key == "optimized_kernel_path"
          and basename == "optimized_kernel.py"
        ):
          should_save = True
        elif state_key == "base_kernel_path" and basename == "base_kernel.py":
          should_save = True
        elif (
          state_key == "kernel_plan_path"
          and file_path.endswith(".md")
          and "plan" in basename
        ):
          should_save = True

        if should_save:
          tool_context.state[state_key] = file_path
          logging.info(
            f"Saved file path to {state_key}: {file_path} (from tool: {tool.name})"
          )
        else:
          logging.info(f"file path {file_path} does not match {state_key}")
    return None

  return save_path


def save_optimized_kernel_and_plan_paths(
  tool: BaseTool,
  args: Dict[str, Any],
  tool_context: ToolContext,
  tool_response: Optional[Dict],
) -> Optional[Dict]:
  """Saves both optimized_kernel_path and kernel_plan_path during implementation."""
  if "read" in tool.name.lower() or "write" in tool.name.lower():
    file_path = args.get("path", None)
    if file_path:
      basename = os.path.basename(file_path).lower()
      # Check if this is a plan file based on filename or path
      if "plan" in file_path.lower() and file_path.endswith(".md"):
        tool_context.state["kernel_plan_path"] = file_path
        logging.info(
          f"Saved plan path to kernel_plan_path: {file_path} (from tool: {tool.name})"
        )
      # Otherwise assume it's the kernel file
      elif basename == "optimized_kernel.py":
        tool_context.state["optimized_kernel_path"] = file_path
        logging.info(
          f"Saved kernel path to optimized_kernel_path: {file_path} (from tool: {tool.name})"
        )
  return None


def save_base_kernel_and_plan_paths(
  tool: BaseTool,
  args: Dict[str, Any],
  tool_context: ToolContext,
  tool_response: Optional[Dict],
) -> Optional[Dict]:
  """Saves both base_kernel_path and kernel_plan_path during planning."""
  if "read" in tool.name.lower() or "write" in tool.name.lower():
    file_path = args.get("path", None)
    if file_path:
      basename = os.path.basename(file_path).lower()
      if "plan" in file_path.lower() and file_path.endswith(".md"):
        tool_context.state["kernel_plan_path"] = file_path
        logging.info(
          f"Saved plan path to kernel_plan_path: {file_path} (from tool: {tool.name})"
        )
      elif basename == "base_kernel.py":
        tool_context.state["base_kernel_path"] = file_path
        logging.info(
          f"Saved base kernel path to base_kernel_path: {file_path} (from tool: {tool.name})"
        )
  return None


def load_single_kernel_to_state(callback_context: CallbackContext):
  """
  Loads a single kernel file content into state.
  Uses kernel_file_path to find the file.
  Stores content in 'kernel_code' for use by compilation/profiling agents.
  """
  file_path = callback_context.state.get("optimized_kernel_path", None)

  if file_path:
    try:
      with open(file_path, "r") as f:
        kernel_code = f.read()
      callback_context.state["kernel_code"] = kernel_code
      logging.info(f"Loaded kernel code from {file_path}")
    except Exception as e:
      logging.error(f"Failed to read kernel file: {e}")
      callback_context.state["kernel_code"] = None
  else:
    logging.warning("No kernel file path found in state")


def load_profiling_script_to_state(callback_context: CallbackContext):
  """
  Loads profiling script file content into state.
  Uses profiling_script_path to find the file.
  Stores content in 'profiling_script' for use by profiling execution agent.
  """
  file_path = callback_context.state.get("profiling_script_path", None)

  if file_path:
    try:
      with open(file_path, "r") as f:
        profiling_code = f.read()
      callback_context.state["profiling_script"] = profiling_code
      logging.info(f"Loaded profiling script from {file_path}")
    except Exception as e:
      logging.error(f"Failed to read profiling script file: {e}")
      callback_context.state["profiling_script"] = None
  else:
    logging.warning("No profiling script path found in state")


def load_two_kernels_to_state(callback_context: CallbackContext):
  """
  Loads two kernel files (base and optimized) into state for comparison.
  Reads from base_kernel_path and optimized_kernel_path.
  Stores contents in base_kernel_code and optimized_kernel_code.
  """
  base_path = callback_context.state.get("base_kernel_path", None)
  optimized_path = callback_context.state.get("optimized_kernel_path", None)

  if base_path:
    try:
      with open(base_path, "r") as f:
        base_code = f.read()
      callback_context.state["base_kernel_code"] = base_code
      logging.info(f"Loaded base kernel code from {base_path}")
    except Exception as e:
      logging.error(f"Failed to read base kernel file: {e}")
      callback_context.state["base_kernel_code"] = None
  else:
    logging.warning("No base kernel path found in state")

  if optimized_path:
    try:
      with open(optimized_path, "r") as f:
        optimized_code = f.read()
      callback_context.state["optimized_kernel_code"] = optimized_code
      logging.info(f"Loaded optimized kernel code from {optimized_path}")
    except Exception as e:
      logging.error(f"Failed to read optimized kernel file: {e}")
      callback_context.state["optimized_kernel_code"] = None
  else:
    logging.warning("No optimized kernel path found in state")


def load_kernel_and_plan_to_state(callback_context: CallbackContext):
  """
  Loads kernel file and optimization plan into state for compilation fixing.
  Uses optimized_kernel_path and kernel_plan_path to find files.
  Stores content in 'kernel_code' and 'kernel_plan' for use by fix agent.
  Also formats compilation_history for better readability.
  """
  # Load kernel code
  kernel_path = callback_context.state.get("optimized_kernel_path", None)
  if kernel_path and os.path.exists(kernel_path):
    try:
      with open(kernel_path, "r") as f:
        kernel_code = f.read()
      callback_context.state["kernel_code"] = kernel_code
      logging.info(f"Loaded kernel code from {kernel_path}")
    except Exception as e:
      logging.error(f"Failed to read kernel file: {e}")
      callback_context.state["kernel_code"] = None
  else:
    logging.warning("No kernel file path found in state or file does not exist")
    callback_context.state["kernel_code"] = None

  # Load optimization plan if exists
  plan_path = callback_context.state.get("kernel_plan_path", None)
  if plan_path and os.path.exists(plan_path):
    try:
      with open(plan_path, "r") as f:
        kernel_plan = f.read()
      callback_context.state["kernel_plan"] = kernel_plan
      logging.info(f"Loaded optimization plan from {plan_path}")
    except Exception as e:
      logging.error(f"Failed to read plan file: {e}")
      callback_context.state["kernel_plan"] = None
  else:
    logging.info(
      "No optimization plan path found (this is okay for some workflows)"
    )
    callback_context.state["kernel_plan"] = None

  # Format compilation history for readability
  history = callback_context.state.get("compilation_history", [])
  if history:
    formatted_history = []
    for record in history:
      attempt_num = record.get("attempt", "?")
      success = record.get("success", False)
      result = record.get("result", "Unknown")
      fix_summary = record.get("fix_summary", None)

      status = "✓ SUCCESS" if success else "✗ FAILED"
      formatted_history.append(f"**Attempt {attempt_num}:** {status}")

      if not success:
        # Include the fix that was attempted (if available)
        if fix_summary:
          formatted_history.append(f"Fix Applied: {fix_summary}")

      formatted_history.append("")  # Blank line

    # Store formatted version in a separate key for the prompt
    callback_context.state["compilation_history_formatted"] = "\n".join(
      formatted_history
    )
  else:
    callback_context.state["compilation_history_formatted"] = (
      "No previous attempts (this is the first attempt)"
    )


def get_tpu_version_callback(callback_context: CallbackContext):
  """Load TPU version and specifications into state."""
  tpu_version = TPU_VERSION

  callback_context.state["tpu_version"] = tpu_version
  logging.info(f"Detected TPU version: {tpu_version}")

  try:
    with open("auto_agent/tpu_specs.json", "r") as f:
      tpu_specs = json.load(f)

    if tpu_version in tpu_specs:
      callback_context.state["tpu_specs"] = tpu_specs[tpu_version]
    else:
      callback_context.state["tpu_specs"] = (
        "TPU specs not found for detected version."
      )
    logging.info(f"Loaded TPU specs for {tpu_version}")
  except Exception as e:
    logging.error(f"Failed to load TPU specs: {e}")
    callback_context.state["tpu_specs"] = None


def add_workdir_callback(callback_context: CallbackContext):
  """Add working directory to state."""
  session_id = callback_context.session.id
  session_dir = os.path.join(WORKDIR, session_id)
  os.makedirs(session_dir, exist_ok=True)
  callback_context.state["workdir"] = session_dir
  logging.info(f"Set working directory to: {session_dir}")


def extract_fix_summary(
  callback_context: CallbackContext, llm_response: LlmResponse
) -> LlmResponse:
  """Extract the agent's response and store it as the fix summary.

  This is an after_model_callback that receives the LlmResponse directly.
  """
  if llm_response.content is None or not llm_response.content.parts:
    logging.warning("No content in LlmResponse to extract fix summary from")
    return llm_response

  # Collect all text parts from the response
  text_parts = []
  for part in llm_response.content.parts:
    if hasattr(part, "text") and part.text:
      text_parts.append(part.text)

  if text_parts:
    # Join all text parts and store as fix summary
    fix_summary = "\n".join(text_parts).strip()
    callback_context.state["fix_summary"] = fix_summary
    logging.info(f"Captured fix summary ({len(fix_summary)} chars)")
  else:
    logging.warning("No text parts found in LlmResponse")

  return llm_response


def add_pallas_docs(callback_context: CallbackContext):
  """Adds the full Pallas documentation to the callback context."""
  callback_context.state["pallas_docs"] = pallas_docs.PROMPT
  callback_context.state["pallas_profiling_docs"] = pallas_profiling_docs.PROMPT


def _is_tool_part(p) -> bool:
  """Checks if a Part represents a tool call or response.

  Supports raw attributes (snake_case/camelCase) for self-history, and ADK
  serialized text logs (`] called tool ``) for upstream subagent history.
  """
  if getattr(p, "function_call", None) or getattr(p, "functionCall", None):
    return True
  if getattr(p, "function_response", None) or getattr(
    p, "functionResponse", None
  ):
    return True

  text_attr = getattr(p, "text", None)
  if text_attr:
    txt = text_attr.strip()
    if "] called tool `" in txt:
      return True
    if "] `" in txt and " tool returned result:" in txt:
      return True

  return False


def prune_intermediate_tool_history(
  callback_context: CallbackContext, llm_request: LlmRequest
) -> Optional[LlmResponse]:
  """Prunes historical tool turns from llm_request.contents.

  Preserves active trailing tool turns and text summaries.
  """
  if not llm_request.contents or len(llm_request.contents) <= 2:
    return None

  contents = llm_request.contents

  # Find where the trailing tool-calling sequence (if any) starts at the end
  # of contents
  trailing_idx = len(contents)
  while trailing_idx > 0:
    last_content = contents[trailing_idx - 1]
    parts = getattr(last_content, "parts", None) or []
    if any(_is_tool_part(p) for p in parts):
      trailing_idx -= 1
    else:
      break

  active_trailing_contents = contents[trailing_idx:]
  history_contents = contents[:trailing_idx]

  filtered_history = []
  for c in history_contents:
    parts = getattr(c, "parts", None) or []
    # Remove tool call/response parts (both raw attributes and serialized logs)
    new_parts = [p for p in parts if not _is_tool_part(p)]
    # Keep the turn if there is at least one meaningful part remaining
    # (not just an orphaned 'For context:' header left after removing tool logs)
    if any(
      (getattr(p, "text", None) or "").strip() != "For context:"
      for p in new_parts
    ):
      filtered_history.append(types.Content(role=c.role, parts=new_parts))

  pruned_count = len(contents) - (
    len(filtered_history) + len(active_trailing_contents)
  )
  if pruned_count > 0:
    logging.info(
      f"prune_intermediate_tool_history: pruned {pruned_count} "
      "historical tool turns."
    )
  llm_request.contents = filtered_history + active_trailing_contents
  return None


__all__ = [
  "create_path_saver",
  "save_optimized_kernel_and_plan_paths",
  "load_single_kernel_to_state",
  "load_profiling_script_to_state",
  "load_two_kernels_to_state",
  "load_kernel_and_plan_to_state",
  "get_tpu_version_callback",
  "add_workdir_callback",
  "extract_fix_summary",
  "add_pallas_docs",
  "prune_intermediate_tool_history",
]
