# Copyright 2025 DeepMind Technologies Limited. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ==============================================================================
"""Flash Attention Pallas-Mosaic-GPU VJP implementation."""

import functools
import math
from typing import cast

import jax
from jax import lax
from jax.experimental import pallas as pl
import jax.experimental.pallas.mosaic_gpu as plgpu
import jax.numpy as jnp
from jaxtyping import Array, Bool, Float, Int  # pylint: disable=g-multiple-import,g-importing-member
from tokamax._src import jaxtyping
from tokamax._src import mosaic_gpu as mgpu_lib
from tokamax._src import shape as shape_lib
from tokamax._src.ops import op
from tokamax._src.ops.attention import base
from tokamax._src.ops.attention import pallas_mosaic_gpu_common as common
from tokamax._src.ops.attention import pallas_mosaic_gpu_vjp_common as vjp_common

Config = vjp_common.Config
Residuals = base.Residuals

_WGMMA = plgpu.Layout.WGMMA
_WGMMA_COL = plgpu.Layout.WGMMA.reduce(0)
_WGMMA_ROW = plgpu.Layout.WGMMA.reduce(1)
_WGMMA_TRANSPOSED = plgpu.Layout.WGMMA_TRANSPOSED
_SMEM_SIZE_BYTES = 227 * 1024
_F32_BYTES = 4
_load_bcast = common.load_bcast
_tiled_spec = mgpu_lib.tiled_swizzled_block_spec


def _estimate_dq_smem_bytes(ba, block_q, block_kv, num_stages, ds_dtype):
  """Estimates the dq kernel smem usage in bytes for a given configuration."""
  _, _, _, q, k, v = ba.args
  tile_q = 2 * block_q

  # 32-bit floats are downcast to 16-bit before the kernel call.
  dtype_bits = jnp.finfo(jnp.bfloat16).bits
  block_d = pl.cdiv(q.shape[-1], 64) * 64
  block_d_out = v.shape[-1]
  bytes_per_stage = block_kv * (block_d + block_d_out) * dtype_bits // 8  # k,v
  if (bias := ba.kwargs["bias"]) is None:
    ds_bytes = 0
  else:
    ds_bytes = tile_q * block_kv * jnp.finfo(ds_dtype).bits // 8
    if bias.shape[-2] != 1 and bias.shape[-1] != 1:
      bytes_per_stage += tile_q * block_kv * jnp.finfo(bias.dtype).bits // 8

  mask = ba.kwargs["mask"]
  q_indices = ba.kwargs["q_indices"]
  k_indices = ba.kwargs["k_indices"]
  mask, *_ = jax.eval_shape(
      common.decompose_mask, mask, q, k, q_indices, k_indices
  )
  if mask is not None and mask.shape[-2] != 1 and mask.shape[-1] != 1:
    bytes_per_stage += tile_q * block_kv

  return (
      (tile_q * (block_d + block_d_out) * dtype_bits // 8)  # q, dout
      + 3 * tile_q * _F32_BYTES  # m, l, delta
      + ds_bytes
      + num_stages * bytes_per_stage
  )


def _estimate_dkv_smem_bytes(ba, block_q, block_kv, num_stages):
  """Estimates the dkv kernel smem usage in bytes for a given configuration."""
  _, _, _, q, k, v = ba.args
  tile_kv = 2 * block_kv

  # 32-bit floats are downcast to 16-bit before the kernel call.
  dtype_bits = jnp.finfo(jnp.bfloat16).bits
  block_d = pl.cdiv(q.shape[-1], 64) * 64
  block_d_out = v.shape[-1]
  bytes_per_stage = block_q * (block_d + block_d_out) * dtype_bits // 8  # q, do
  bytes_per_stage += 3 * block_q * _F32_BYTES  # m, l, delta
  if (bias := ba.kwargs["bias"]) is not None:
    if bias.shape[-2] != 1 and bias.shape[-1] != 1:
      bytes_per_stage += block_q * tile_kv * jnp.finfo(bias.dtype).bits // 8

  mask = ba.kwargs["mask"]
  q_indices = ba.kwargs["q_indices"]
  k_indices = ba.kwargs["k_indices"]
  mask, *_ = jax.eval_shape(
      common.decompose_mask, mask, q, k, q_indices, k_indices
  )
  if mask is not None and mask.shape[-2] != 1 and mask.shape[-1] != 1:
    bytes_per_stage += block_q * tile_kv

  return (
      tile_kv * (block_d + block_d_out) * dtype_bits // 8
  ) + num_stages * bytes_per_stage  # k, v


def get_heuristics_config(ba: op.BoundArguments) -> Config:
  _, _, _, q, k, _ = ba.args
  bias = ba.kwargs["bias"]
  dbias_intermediate_dtype = getattr(ba.op, "dbias_intermediate_dtype", None)
  ds_dtype = vjp_common.get_ds_dtype(q, k, bias, dbias_intermediate_dtype)

  num_stages = 2
  if _estimate_dq_smem_bytes(ba, 64, 64, 2, ds_dtype) > _SMEM_SIZE_BYTES:
    num_stages = 1
  if _estimate_dkv_smem_bytes(ba, 64, 64, 2) > _SMEM_SIZE_BYTES:
    num_stages = 1

  return Config(
      block_q_dkv=64,
      block_kv_dkv=64,
      block_q_dq=64,
      block_kv_dq=64,
      num_stages=num_stages,
  )


def get_autotuning_configs(ba: op.BoundArguments) -> set[Config]:
  # TODO: Expand vjp search space.
  del ba
  configs = set()
  for block_q in [64, 128]:
    for block_kv in [64, 128]:
      for num_stages in [2, 3]:
        for compute_wgs in [1, 2]:
          configs.add(
              Config(
                  block_q_dkv=block_q,
                  block_kv_dkv=block_kv,
                  block_q_dq=block_q,
                  block_kv_dq=block_kv,
                  num_stages=num_stages,
                  compute_wgs=compute_wgs,
              )
          )
  return configs


@jaxtyping.jaxtyped
def flash_attention_vjp_kernel(
    q: Float[Array, "T H D"],
    k: Float[Array, "t h D"],
    v: Float[Array, "t h d"],
    residuals: Residuals,
    out: Float[Array, "T H d"],
    dout: Float[Array, "T H d"],
    bias: Float[Array, "#H #T #t"] | None,
    mask: Bool[Array, "#H #T #t"] | None,
    k_start: Int[Array, "#H #T"] | None,
    k_end: Int[Array, "#H #T"] | None,
    *,
    logits_scale: float,
    logits_soft_cap: float | None,
    is_causal: bool,
    ds_dtype: jax.typing.DTypeLike | None,
    config: Config,
) -> tuple[
    Float[Array, "T H D"],  # dq
    Float[Array, "t h D"],  # dk
    Float[Array, "t h d"],  # dv
    Float[Array, "H T t"] | None,  # ds
]:
  orig_q_seq_len, _, orig_head_dim = q.shape
  orig_head_dim_out = v.shape[-1]
  pad_head_dim = lambda x: shape_lib.pad_to_next_multiple_of(x, 64, -1)
  q, k, v, out, dout = map(pad_head_dim, (q, k, v, out, dout))
  m, l = residuals

  # TODO: Remove padding along q sequence length.
  pad_q_seq = lambda x, a: shape_lib.pad_to_next_multiple_of(x, 8, a)
  q, m, l = map(pad_q_seq, (q, m, l), (-3, -1, -1))

  q_seq_len, num_q_heads, head_dim = q.shape
  kv_seq_len, num_kv_heads, head_dim_out = v.shape
  if (dtype := q.dtype) != k.dtype or dtype != v.dtype:
    raise ValueError(
        f"q, k, and v should all have the same dtype, got: {q.dtype},"
        f" {k.dtype}, {v.dtype}"
    )
  if num_q_heads % num_kv_heads:
    raise ValueError(f"{num_q_heads=} must be divisible by and {num_kv_heads=}")
  q_heads_per_kv_head = num_q_heads // num_kv_heads

  block_q_dq = config.block_q_dq
  block_q_dkv = config.block_q_dkv
  block_kv_dkv = config.block_kv_dkv
  block_kv_dq = config.block_kv_dq
  compute_wgs = config.compute_wgs

  if mask is not None:
    mask = mask.astype(jnp.int8)

  # TODO: Avoid broadcast.
  bcast = lambda x: jnp.broadcast_to(x, (x.shape[-2], q_seq_len))
  k_start = None if k_start is None else bcast(k_start)
  k_end = None if k_end is None else bcast(k_end)
  has_k_range = k_start is not None or k_end is not None
  delta = jnp.einsum(
      "qhd,qhd->hq", out, dout, preferred_element_type=jnp.float32
  )
  delta = pad_q_seq(delta, -1)

  def kernel_dq(
      q_gmem,
      k_gmem,
      v_gmem,
      dout_gmem,
      m_gmem,
      l_gmem,
      delta_gmem,
      bias_gmem,
      mask_gmem,
      k_start_gmem,
      k_end_gmem,
      dq_gmem,
      ds_gmem,
      q_smems,
      dout_smems,
      ds_smems,
      barriers,
      block_q: int,
      block_kv: int,
  ):
    qi = lax.axis_index("q_tiles")
    hi = lax.axis_index("heads")
    wg = lax.axis_index("wg")
    hi_kv = lax.div(hi, jnp.array(q_heads_per_kv_head, hi.dtype))

    tile_q = compute_wgs * block_q
    q_base = qi * tile_q + wg * block_q
    qs = cast(pl.Slice, pl.ds(q_base, block_q))

    lb = 0
    ub = num_kv_tiles = pl.cdiv(kv_seq_len, block_kv_dq)
    if is_causal:
      ub = lax.min(ub, pl.cdiv(qi * tile_q + tile_q, block_kv))

    k_gmem = k_gmem.at[:, hi_kv]
    v_gmem = v_gmem.at[:, hi_kv]
    if bias_gmem is not None:
      bias_gmem = bias_gmem.at[0 if bias_gmem.shape[0] == 1 else hi]
    if mask_gmem is not None:
      mask_gmem = mask_gmem.at[0 if mask_gmem.shape[0] == 1 else hi]

    q_smem = q_smems.at[wg]
    dout_smem = dout_smems.at[wg]
    ds_smem = None if ds_smems is None else ds_smems.at[wg]
    barrier = barriers.at[wg]

    def compute_thread(pipeline_callback):
      plgpu.copy_gmem_to_smem(q_gmem.at[qs, hi], q_smem, barrier)
      plgpu.copy_gmem_to_smem(dout_gmem.at[qs, hi], dout_smem, barrier)

      delta = plgpu.load(
          delta_gmem.at[hi, qs], layout=_WGMMA_ROW, optimized=False
      )
      m = plgpu.load(m_gmem.at[hi, qs], layout=_WGMMA_ROW, optimized=False)
      l = plgpu.load(l_gmem.at[hi, qs], layout=_WGMMA_ROW, optimized=False)

      def load_k_range(ref):
        if ref is None:
          return None
        idx = (0 if ref.shape[0] == 1 else hi, qs)
        return plgpu.load(ref.at[idx], layout=_WGMMA_ROW, optimized=False)

      k_start = load_k_range(k_start_gmem)
      k_end = load_k_range(k_end_gmem)
      m_valid = (mask is None and not has_k_range) | (m != -jnp.inf)
      m = jnp.where(m_valid, m * math.log2(math.e), 0.0)
      l_rcp = 1.0 / (l + jnp.finfo(jnp.float32).tiny)

      plgpu.barrier_wait(barrier)

      def compute_dq(dq_acc):
        _ = pipeline_callback((dq_acc, m, l_rcp, delta, k_start, k_end))
        return dq_acc[...] * logits_scale

      dq = pl.run_scoped(compute_dq, plgpu.ACC(q_smem.shape, jnp.float32))
      q_smem[...] = dq.astype(dtype)
      plgpu.commit_smem()
      plgpu.copy_smem_to_gmem(q_smem, dq_gmem.at[qs, hi])

      if ds_gmem is not None:  # Zero `ds` for the kv tiles that are not used.

        @pl.loop(ub, num_kv_tiles)
        def zero_ds(ki):
          ks = pl.ds(ki * block_kv, block_kv)
          ds_gmem_ = ds_gmem.at[hi, qs, ks]
          ds_gmem_[...] = jnp.zeros_like(ds_gmem_)  # TODO

      plgpu.wait_smem_to_gmem(0, wait_read_only=True)

    # TODO: If bias/mask are broadcast along k, we can load outside the
    # pipeline as they are not dependent on kv_step.
    def kv_pipeline(
        index,
        bias_smem,
        v_smem,
        mask_smem,
        k_smem,
        bias_consumed,
        v_consumed,
        mask_consumed,
        k_consumed,
        carry,
    ):
      (i,) = index
      ki = lb + i
      kv_base = ki * block_kv
      ks = cast(pl.Slice, pl.ds(kv_base, block_kv))
      dq_acc, m, l_rcp, delta, k_start, k_end = carry

      def compute_dp_s(dp_acc, s_acc):
        plgpu.wgmma(dp_acc, dout_smem, v_smem.T)
        plgpu.wgmma(s_acc, q_smem, k_smem.T)

        if bias_gmem is None:
          bias = None
        elif bias_smem is None:
          bias = _load_bcast(bias_gmem, (qs, ks), layout=_WGMMA)
        else:
          bias = bias_smem[pl.ds(wg * block_q, block_q)]
          mgpu_lib.fence_async_shared_cta()
          plgpu.barrier_arrive(bias_consumed)

        plgpu.wgmma_wait(1)
        plgpu.barrier_arrive(v_consumed)
        return dp_acc[...], s_acc[...], bias

      acc_type = plgpu.ACC((block_q, block_kv), jnp.float32)
      dp, s, bias = pl.run_scoped(compute_dp_s, acc_type, acc_type)
      scale = logits_scale

      if bias is not None:
        s, scale = s * scale + bias.astype(s.dtype), 1.0

      if logits_soft_cap is not None:
        s, scale = jnp.tanh(s * (scale / logits_soft_cap)), logits_soft_cap
      logits = s

      def iota(d):
        return plgpu.broadcasted_iota(jnp.int32, s.shape, d, layout=_WGMMA)

      if is_causal:

        def apply_causal_mask():
          return jnp.where(q_base + iota(0) >= kv_base + iota(1), s, -jnp.inf)

        s = lax.cond(kv_base + block_kv > q_base, apply_causal_mask, lambda: s)

      bcast = lambda x: lax.broadcast_in_dim(x, s.shape, [0])

      if k_start is not None:
        s = jnp.where(kv_base + iota(1) >= bcast(k_start), s, -jnp.inf)

      if k_end is not None:
        s = jnp.where(kv_base + iota(1) < bcast(k_end), s, -jnp.inf)

      if mask_gmem is not None:
        if mask_smem is None:
          mask = _load_bcast(mask_gmem, (qs, ks), layout=_WGMMA)
        else:
          if mask_smem.ndim == 1:
            mask = plgpu.load(mask_smem, layout=_WGMMA_COL)
            mask = lax.broadcast_in_dim(mask, s.shape, [1])
          else:
            mask = mask_smem[pl.ds(wg * block_q, block_q)]
          mgpu_lib.fence_async_shared_cta()
          plgpu.barrier_arrive(mask_consumed)

        s = jnp.where(mask, s, -jnp.inf)

      p = jnp.exp2(s * (scale * math.log2(math.e)) - bcast(m)) * bcast(l_rcp)
      ds = p * (dp - bcast(delta))

      if logits_soft_cap is not None:
        ds *= 1.0 - logits * logits

      if ds_gmem is not None:
        assert ds_smem is not None
        plgpu.wait_smem_to_gmem(0, wait_read_only=True)
        ds_smem[...] = ds.astype(ds_smem.dtype)
        plgpu.commit_smem()
        plgpu.copy_smem_to_gmem(ds_smem, ds_gmem.at[hi, qs, ks])

      plgpu.wgmma(dq_acc, ds.astype(k_smem.dtype), k_smem)
      plgpu.wgmma_wait(0)
      plgpu.barrier_arrive(k_consumed)
      return dq_acc, m, l_rcp, delta, k_start, k_end

    k_spec = _tiled_spec(
        (block_kv, head_dim), k.dtype, lambda i: (lb + i, 0), "k"
    )
    v_spec = _tiled_spec(
        (block_kv, head_dim_out), v.dtype, lambda i: (lb + i, 0), "v"
    )

    if bias is not None and bias.shape[-2] != 1 and bias.shape[-1] != 1:
      bias_gmem_ = bias_gmem
      bias_spec = _tiled_spec(
          (tile_q, block_kv), bias.dtype, lambda i: (qi, lb + i), "bias"
      )
    else:
      bias_gmem_ = bias_spec = None

    mask_gmem_ = mask_spec = None
    if mask is not None and mask.shape[-1] != 1:
      if mask.shape[-2] == 1:
        if block_kv >= 128:  # Minimum transfer size is 128 bytes.
          mask_gmem_ = mask_gmem
          mask_spec = plgpu.BlockSpec((None, block_kv), lambda i: (0, lb + i))
      else:
        mask_gmem_ = mask_gmem
        mask_spec = _tiled_spec(
            (tile_q, block_kv), mask.dtype, lambda i: (qi, lb + i), "mask"
        )

    plgpu.emit_pipeline_warp_specialized(
        kv_pipeline,
        grid=(ub - lb,),
        max_concurrent_steps=min(config.num_stages, num_kv_tiles),
        num_compute_wgs=compute_wgs,
        memory_registers=40,
        wg_axis="wg",
        manual_consumed_barriers=True,
        compute_context=compute_thread,
        in_specs=[bias_spec, v_spec, mask_spec, k_spec],  # pyrefly: ignore[bad-argument-type]
    )(bias_gmem_, v_gmem, mask_gmem_, k_gmem)

  def kernel_dkv(
      q_gmem,
      k_gmem,
      v_gmem,
      dout_gmem,
      m_gmem,
      l_gmem,
      delta_gmem,
      bias_gmem,
      mask_gmem,
      k_start_gmem,
      k_end_gmem,
      dk_gmem,
      dv_gmem,
      k_smems,
      v_smems,
      barriers,
      block_q: int,
      block_kv: int,
  ):
    ki = lax.axis_index("kv_tiles")
    hi_kv = lax.axis_index("heads")
    wg = lax.axis_index("wg")

    tile_kv = compute_wgs * block_kv
    kv_base = ki * tile_kv + wg * block_kv
    ks = cast(pl.Slice, pl.ds(kv_base, block_kv))
    lb = lax.div(ki * tile_kv, block_q) if is_causal else 0
    ub = num_q_tiles = pl.cdiv(q_seq_len, block_q)

    k_smem = k_smems.at[wg]
    v_smem = v_smems.at[wg]
    barrier = barriers.at[wg]

    def compute_thread(pipeline_callback):
      plgpu.copy_gmem_to_smem(k_gmem.at[ks, hi_kv], k_smem, barrier)
      plgpu.copy_gmem_to_smem(v_gmem.at[ks, hi_kv], v_smem, barrier)
      if mask_gmem is None:
        mask = None
      elif mask_gmem.shape[-3] != 1 or mask_gmem.shape[-1] != 1:
        mask = None
      else:  # The mask is loop invariant.
        idx = (0, ks, 0)
        mask = plgpu.load(mask_gmem.at[idx], layout=_WGMMA_ROW, optimized=False)
      plgpu.barrier_wait(barrier)

      def compute_dk_dv(dk_acc, dv_acc):
        _ = pipeline_callback((dk_acc, dv_acc, mask))
        return dk_acc[...], dv_acc[...]

      dk_acc_type = plgpu.ACC(k_smem.shape, jnp.float32)
      dv_acc_type = plgpu.ACC(v_smem.shape, jnp.float32)
      dk, dv = pl.run_scoped(compute_dk_dv, dk_acc_type, dv_acc_type)
      k_smem[...] = (dk * logits_scale).astype(k.dtype)
      v_smem[...] = dv.astype(v.dtype)

      plgpu.commit_smem()
      plgpu.copy_smem_to_gmem(k_smem, dk_gmem.at[ks, hi_kv], commit_group=False)
      plgpu.copy_smem_to_gmem(v_smem, dv_gmem.at[ks, hi_kv], commit_group=False)
      plgpu.commit_smem_to_gmem_group()
      plgpu.wait_smem_to_gmem(0, wait_read_only=True)

    # TODO: If bias/mask are broadcast along q, we can load outside the
    # pipeline as they are not dependent on q_step.
    def q_pipeline(
        index,
        bias_smem,
        m_smem,
        l_smem,
        delta_smem,
        mask_smem,
        dout_smem,
        q_smem,
        bias_consumed,
        m_consumed,
        l_consumed,
        delta_consumed,
        mask_consumed,
        dout_consumed,
        q_consumed,
        carry,
    ):
      i, j = index
      qi = lb + i
      q_base = qi * block_q
      qs = cast(pl.Slice, pl.ds(q_base, block_q))
      hi = q_heads_per_kv_head * j + hi_kv
      dk_acc, dv_acc, loop_invariant_mask = carry

      def compute_s(acc):
        plgpu.wgmma(acc, k_smem, q_smem.T)
        if bias_gmem is None:
          bias = None
        elif bias_smem is None:
          bias_hi = 0 if bias_gmem.shape[0] == 1 else hi
          bias = _load_bcast(bias_gmem.at[bias_hi].T, (ks, qs), layout=_WGMMA)
        else:
          idx = pl.ds(wg * block_kv, block_kv)
          bias = plgpu.load(bias_smem.T.at[idx], layout=_WGMMA_TRANSPOSED)
          plgpu.barrier_arrive(bias_consumed)

        m = plgpu.load(m_smem, layout=_WGMMA_COL)
        l = plgpu.load(l_smem, layout=_WGMMA_COL)
        delta = plgpu.load(delta_smem, layout=_WGMMA_COL)
        plgpu.barrier_arrive(m_consumed)
        plgpu.barrier_arrive(l_consumed)
        plgpu.barrier_arrive(delta_consumed)
        return acc[...], bias, m, l, delta

      acc_type = plgpu.ACC((block_kv, block_q), jnp.float32)
      s, bias, m, l, delta = pl.run_scoped(compute_s, acc_type)
      scale = logits_scale

      if bias is not None:
        s = s * scale + plgpu.layout_cast(bias.astype(s.dtype), _WGMMA)
        scale = 1.0

      if logits_soft_cap is not None:
        s, scale = jnp.tanh(s * (scale / logits_soft_cap)), logits_soft_cap
      logits = s

      scale *= math.log2(math.e)
      m *= math.log2(math.e)

      def iota(d):
        return plgpu.broadcasted_iota(jnp.int32, s.shape, d, layout=_WGMMA)

      if is_causal:

        def apply_causal_mask():
          return jnp.where(kv_base + iota(0) <= q_base + iota(1), s, -jnp.inf)

        s = lax.cond(kv_base + block_kv > q_base, apply_causal_mask, lambda: s)

      bcast = lambda x: lax.broadcast_in_dim(x, s.shape, [1])

      def load_k_range(ref):
        hi_ = 0 if ref.shape[0] == 1 else hi
        return plgpu.load(ref.at[hi_, qs], layout=_WGMMA_COL, optimized=False)

      if k_start_gmem is not None:
        k_start = bcast(load_k_range(k_start_gmem))
        s = jnp.where(kv_base + iota(0) >= k_start, s, -jnp.inf)

      if k_end_gmem is not None:
        k_end = bcast(load_k_range(k_end_gmem))
        s = jnp.where(kv_base + iota(0) < k_end, s, -jnp.inf)

      if mask_gmem is not None:
        if mask_smem is None:
          if loop_invariant_mask is None:
            mask_hi = 0 if mask_gmem.shape[0] == 1 else hi
            mask = _load_bcast(mask_gmem, (mask_hi, ks, qs), layout=_WGMMA)
          else:
            mask = lax.broadcast_in_dim(loop_invariant_mask, s.shape, [0])
        else:
          mask = mask_smem[pl.ds(wg * block_kv, block_kv)]
          plgpu.barrier_arrive(mask_consumed)

        s = jnp.where(mask, s, -jnp.inf)

      m_valid = (mask_gmem is None and not has_k_range) | (m != -jnp.inf)
      m = jnp.where(m_valid, m, 0.0)
      epsilon = float(jnp.finfo(jnp.float32).tiny)  # Avoid division by zero.
      p = jnp.exp2(s * scale - bcast(m)) / bcast(l + epsilon)

      def compute_dp(acc):
        plgpu.wgmma(acc, v_smem, dout_smem.T)
        plgpu.wgmma(dv_acc, p.astype(dtype), dout_smem)
        # Load dP without waiting for the dV matmul to complete.
        return plgpu.wgmma_accumulator_load(acc, wait_n=1)

      dp = pl.run_scoped(compute_dp, acc_type)
      ds = p * (dp - bcast(delta))
      if logits_soft_cap is not None:
        ds *= 1.0 - logits * logits

      plgpu.wgmma(dk_acc, ds.astype(dtype), q_smem)
      plgpu.wgmma_wait(1)
      plgpu.barrier_arrive(dout_consumed)
      plgpu.wgmma_wait(0)
      plgpu.barrier_arrive(q_consumed)
      return dk_acc, dv_acc, loop_invariant_mask

    def f(index_map):
      return lambda i, j: index_map(lb + i, q_heads_per_kv_head * hi_kv + j)

    q_spec = _tiled_spec(
        (block_q, None, head_dim), q.dtype, f(lambda qi, hi: (qi, hi, 0)), "q"
    )
    dout_spec = _tiled_spec(
        (block_q, None, head_dim_out),
        dout.dtype,
        f(lambda qi, hi: (qi, hi, 0)),
        "dout",
    )
    m_spec = l_spec = delta_spec = plgpu.BlockSpec(
        (None, block_q), f(lambda qi, hi: (hi, qi))
    )

    if bias is not None and bias.shape[-2] != 1 and bias.shape[-1] != 1:
      bias_gmem_ = bias_gmem
      bias_spec = _tiled_spec(
          (None, block_q, tile_kv),
          bias.dtype,
          f(lambda qi, hi: (0 if bias.shape[0] == 1 else hi, qi, ki)),
          "bias",
      )
    else:
      bias_gmem_ = bias_spec = None

    if mask is not None and mask.shape[-2] != 1 and mask.shape[-1] != 1:
      mask_gmem_ = mask_gmem
      mask_spec = _tiled_spec(
          (None, tile_kv, block_q),
          mask.dtype,
          f(lambda qi, hi: (0 if mask.shape[0] == 1 else hi, ki, qi)),
          "mask",
      )
    else:
      mask_gmem_ = mask_spec = None

    plgpu.emit_pipeline_warp_specialized(
        q_pipeline,
        grid=(ub - lb, q_heads_per_kv_head),
        max_concurrent_steps=min(config.num_stages, num_q_tiles),
        num_compute_wgs=compute_wgs,
        memory_registers=40,
        wg_axis="wg",
        manual_consumed_barriers=True,
        compute_context=compute_thread,
        in_specs=[  # pyrefly: ignore[bad-argument-type]
            bias_spec,
            m_spec,
            l_spec,
            delta_spec,
            mask_spec,
            dout_spec,
            q_spec,
        ],
    )(bias_gmem_, m_gmem, l_gmem, delta_gmem, mask_gmem_, dout_gmem, q_gmem)

  def tiled_wgs_smem(shape, dtype, what=""):
    return mgpu_lib.tiled_swizzled_smem((compute_wgs, *shape), dtype, what)

  tile_q_dq = compute_wgs * block_q_dq
  if bias is None:
    ds_out_shape = None
    ds_scratch = None
  else:
    # NOTE: TMA stores to GMEM do not mask out-of-bounds writes, so we must pad
    # the output to a multiple of the block size.
    q_seq_len_ = pl.cdiv(q_seq_len, tile_q_dq) * tile_q_dq
    kv_seq_len_ = pl.cdiv(kv_seq_len, block_kv_dq) * block_kv_dq
    ds_out_shape = (num_q_heads, q_seq_len_, kv_seq_len_)
    ds_out_shape = jax.ShapeDtypeStruct(ds_out_shape, ds_dtype)
    ds_scratch = tiled_wgs_smem((block_q_dq, block_kv_dq), ds_dtype, "ds")
  # TODO: Optionally fuse the dq and dkv kernels.
  dq, ds = plgpu.kernel(
      functools.partial(kernel_dq, block_q=block_q_dq, block_kv=block_kv_dq),
      out_type=(jax.ShapeDtypeStruct(q.shape, q.dtype), ds_out_shape),
      scratch_types=[
          tiled_wgs_smem((block_q_dq, head_dim), q.dtype, "q"),
          tiled_wgs_smem((block_q_dq, head_dim_out), dout.dtype, "dout"),
          ds_scratch,
          plgpu.Barrier(num_barriers=compute_wgs, num_arrivals=2),
      ],
      compiler_params=plgpu.CompilerParams(approx_math=True),
      grid=(num_q_heads, pl.cdiv(q_seq_len, tile_q_dq)),
      grid_names=("heads", "q_tiles"),
      num_threads=compute_wgs + 1,
      thread_name="wg",
  )(q, k, v, dout, m, l, delta, bias, mask, k_start, k_end)

  # TODO: Fuse transpose in the kernel.
  if mask is not None:
    mask = mask.mT

  tile_kv_dkv = compute_wgs * block_kv_dkv
  dk, dv = plgpu.kernel(
      functools.partial(kernel_dkv, block_q=block_q_dkv, block_kv=block_kv_dkv),
      out_type=(
          jax.ShapeDtypeStruct(k.shape, k.dtype),
          jax.ShapeDtypeStruct(v.shape, v.dtype),
      ),
      scratch_types=[
          tiled_wgs_smem((block_kv_dkv, head_dim), k.dtype, "k"),
          tiled_wgs_smem((block_kv_dkv, head_dim_out), v.dtype, "v"),
          plgpu.Barrier(num_barriers=compute_wgs, num_arrivals=2),
      ],
      compiler_params=plgpu.CompilerParams(approx_math=True),
      grid=(num_kv_heads, pl.cdiv(kv_seq_len, tile_kv_dkv)),
      grid_names=("heads", "kv_tiles"),
      num_threads=compute_wgs + 1,
      thread_name="wg",
  )(q, k, v, dout, m, l, delta, bias, mask, k_start, k_end)

  dq = dq[..., :orig_q_seq_len, :, :orig_head_dim]
  dk = dk[..., :orig_head_dim]
  dv = dv[..., :orig_head_dim_out]
  ds = None if ds is None else ds[:, :orig_q_seq_len, :kv_seq_len]
  return dq, dk, dv, ds
