# Copyright 2026 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ==============================================================================
"""Multi-Head Latent Attention API."""

from typing import Final
from tokamax._src.ops.experimental.mla import base

IMPLEMENTATIONS: Final[dict[str, base.MultiHeadLatentAttention]] = dict(
    xla=base.MultiHeadLatentAttention(),
)

try:
  from tokamax._src.ops.experimental.mla import pallas_mosaic_tpu  # pylint: disable=g-import-not-at-top  # pyrefly: ignore[missing-module-attribute]

  IMPLEMENTATIONS['mosaic_tpu'] = (
      pallas_mosaic_tpu.PallasTpuMultiHeadLatentAttention()
  )
except ImportError:
  pass
